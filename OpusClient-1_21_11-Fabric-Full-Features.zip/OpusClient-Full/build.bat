@echo off
setlocal
where gradle >nul 2>nul
if errorlevel 1 (
  echo Gradle was not found on PATH.
  echo Install Gradle 9.2+ and Java 21, then run this file again.
  pause
  exit /b 1
)
call gradle build
if errorlevel 1 exit /b 1
echo.
echo Build complete. Check build\libs\ for the remapped Opus Client jar.
pause
