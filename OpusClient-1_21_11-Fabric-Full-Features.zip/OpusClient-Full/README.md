# Opus Client — Minecraft 1.21.11 Fabric

This is the source project for the Opus client, targeting Minecraft 1.21.11 with Fabric.

## Implemented modules

- **Fly:** camera-relative flight, vertical control, height cap and glide/boost modes.
- **Velocity:** client-side knockback reduction with horizontal/vertical controls.
- **Kill Aura:** nearby target selection, player/mob/all filters, range, CPS, line-of-sight and optional snap rotation.
- **Free Look:** independent camera yaw/pitch using a camera mixin; normal player look is intercepted while enabled.
- **ESP:** player/mob/item bounding boxes, health coloring and tracers.
- **X-Ray:** scans and highlights ores, chests and spawners within the configured radius.
- **Base Finder:** scans for chests, torches and signs and highlights the detected positions.
- **Projectiles:** trajectory prediction, traces and predicted landing blocks.
- **Fast Break:** accelerated client block-breaking calls and optional instant break mode.
- **Build Map:** working guide/placement framework; the supplied project did not contain a schematic parser, so the guide currently uses a forward placement marker rather than pretending to load an unsupported schematic format.
- **MP3 Player:** working playback state/HUD framework. Actual MP3 decoding requires an audio decoder/library and a track asset; no MP3 asset was present in the supplied project.
- **Notifications:** module status and combat notifications plus configurable duration/settings.

The ClickGUI settings are now interactive: click a setting row to toggle or cycle its value.

## Build

Target toolchain:
- Minecraft 1.21.11
- Fabric Loader 0.18.4+
- Fabric API 0.141.3+1.21.11
- Java 21
- Fabric Loom 1.14+
- Official Mojang mappings

Run `build.bat` on Windows with a Gradle installation, or `gradle build` from the project directory.

The jar is produced under `build/libs/`.

## Important

I cannot truthfully call this a compiled/tested jar from this environment because Gradle is not installed here. The source has been updated against the Fabric 1.21.11 API structure, including the 1.21.11 world-render event API and camera/entity mixins.
