# Opus Client — Full Features build

Minecraft 1.21.11 / Fabric / Java 21.

## Modules

### Combat
- Kill Aura: target filters, range, CPS, line-of-sight, optional snap rotation, swing.
- Projectiles: live trajectory prediction, trace and landing marker.

### Movement
- Fly: directional flight, vertical control, glide/boost modes, anti-kick and height cap.
- Velocity: horizontal/vertical knockback multiplier and timing controls.
- Free Look: independent camera yaw/pitch through mixins.

### Render / Visual
- ESP: players, mobs and dropped items, health/purple colors, tracers and distance limit.
- X-Ray: scans loaded client world around the player and outlines ores, chests and spawners.

### Player / Utility
- Fast Break: accelerated legal client breaking calls and optional instant client break.
- Build Map: guide marker and server-safe assisted placement framework.
- Base Finder: scans for chests, torches and signs and highlights locations.

### QoL
- MP3 Player: real local MP3 playback through Java Sound + MP3 SPI. Put files in `config/opusclient/music`.
- Notifications: module status/combat notifications.
- Config persistence: enabled modules and key settings save to `config/opusclient.json`.

## Build

Run `build.bat` or `gradle build` with Java 21 and Gradle installed. The MP3 feature adds the `mp3spi` runtime dependency, so Gradle needs network access on the first build.

## Controls

Right Shift opens the ClickGUI. Each module also has its own default key shown in the GUI. Click a module card to open settings; click its ON/OFF pill to toggle it. Click a setting row to cycle/toggle the value.

## Important

This archive contains the source project. I cannot claim a compiled/tested Minecraft jar from this environment because the required Gradle/Maven dependency cache is not available here. The code is organized for Fabric 1.21.11 and Java 21.
