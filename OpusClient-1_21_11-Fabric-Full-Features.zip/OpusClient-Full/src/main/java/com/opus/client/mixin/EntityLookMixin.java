package com.opus.client.mixin;

import com.opus.client.module.Modules;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Entity.class)
public abstract class EntityLookMixin {
    @Inject(method = "changeLookDirection", at = @At("HEAD"), cancellable = true)
    private void opus$freeLook(double dx, double dy, CallbackInfo ci) {
        Minecraft mc = Minecraft.getInstance();
        if ((Object)this == mc.player && Modules.FREELOOK.enabled()) {
            Modules.FREELOOK.updateLook(dx, dy);
            ci.cancel();
        }
    }
}
