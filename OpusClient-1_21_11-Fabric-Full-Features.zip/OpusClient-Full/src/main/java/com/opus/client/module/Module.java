package com.opus.client.module;

import com.opus.client.config.OpusConfig;

public abstract class Module {
    public final String name, category, description;
    private boolean enabled;
    public int key;
    protected Module(String name, String category, String description, int key){this.name=name;this.category=category;this.description=description;this.key=key;}
    public boolean enabled(){return enabled;}
    public void toggle(){setEnabled(!enabled);}
    public void setEnabled(boolean v){if(enabled==v)return; enabled=v; if(v)onEnable(); else onDisable(); OpusConfig.save();}
    public void onEnable(){} public void onDisable(){} public void tick(){}
}
