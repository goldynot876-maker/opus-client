package com.opus.client.module;

import com.opus.client.OpusClient;
import com.opus.client.audio.AudioPlayer;
import com.opus.client.render.WorldFeatures;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import org.lwjgl.glfw.GLFW;

import java.util.*;

/** Runtime module registry and implementations for the Opus client. */
public final class Modules {
    public static final List<Module> ALL = new ArrayList<>();
    public static final FlyModule FLY = new FlyModule();
    public static final VelocityModule VELOCITY = new VelocityModule();
    public static final KillAuraModule KILLAURA = new KillAuraModule();
    public static final FreeLookModule FREELOOK = new FreeLookModule();
    public static final ESPModule ESP = new ESPModule();
    public static final XRayModule XRAY = new XRayModule();
    public static final BaseFinderModule BASE = new BaseFinderModule();
    public static final ProjectilesModule PROJECTILES = new ProjectilesModule();
    public static final FastBreakModule FASTBREAK = new FastBreakModule();
    public static final BuildMapModule BUILDMAP = new BuildMapModule();
    public static final MP3Module MP3 = new MP3Module();
    public static final NotificationsModule NOTIFICATIONS = new NotificationsModule();

    static {
        Collections.addAll(ALL, FLY, VELOCITY, KILLAURA, FREELOOK, ESP, XRAY, BASE,
                PROJECTILES, FASTBREAK, BUILDMAP, MP3, NOTIFICATIONS);
    }

    private Modules() {}

    public static void tick() {
        for (Module module : ALL) if (module.enabled()) module.tick();
        WorldFeatures.tick();
    }

    public static long active() { return ALL.stream().filter(Module::enabled).count(); }

    public static class FlyModule extends Module {
        public double speed = 1.5, maxHeight = 320;
        public String mode = "Boost";
        public boolean antiKick = true;
        FlyModule() { super("Fly", "Movement", "Free aerial movement", GLFW.GLFW_KEY_F); }

        @Override public void tick() {
            Minecraft mc = Minecraft.getInstance(); LocalPlayer p = mc.player;
            if (p == null || mc.screen != null) return;
            double s = Math.max(.05, speed);
            if ("Glide".equals(mode)) s *= .55;
            float yaw = p.getYRot();
            double rad = Math.toRadians(yaw);
            double forward = 0, strafe = 0;
            if (mc.options.keyUp.isDown()) forward += 1;
            if (mc.options.keyDown.isDown()) forward -= 1;
            if (mc.options.keyLeft.isDown()) strafe += 1;
            if (mc.options.keyRight.isDown()) strafe -= 1;
            double len = Math.hypot(forward, strafe);
            if (len > 1) { forward /= len; strafe /= len; }
            double x = (-Math.sin(rad) * forward + Math.cos(rad) * strafe) * s;
            double z = (Math.cos(rad) * forward + Math.sin(rad) * strafe) * s;
            double y = 0;
            if (mc.options.keyJump.isDown()) y = s * .65;
            else if (mc.options.keyShift.isDown()) y = -s * .65;
            else if ("Boost".equals(mode)) y = antiKick ? -0.02 : 0;
            p.setDeltaMovement(x, y, z);
            p.fallDistance = 0;
            if (p.getY() > maxHeight) p.setPos(p.getX(), maxHeight, p.getZ());
        }
    }

    public static class VelocityModule extends Module {
        public double delay = 100, multiplier = .35;
        public boolean horizontal = true, vertical = true;
        public int packets = 1;
        VelocityModule() { super("Velocity", "Movement", "Reduce client knockback", GLFW.GLFW_KEY_V); }
        @Override public void tick() {
            LocalPlayer p = Minecraft.getInstance().player;
            if (p == null || p.hurtTime <= 0 || p.hurtTime > delay / 50.0 + 1) return;
            Vec3 v = p.getDeltaMovement();
            double x = horizontal ? v.x * multiplier : v.x;
            double y = vertical ? v.y * multiplier : v.y;
            double z = horizontal ? v.z * multiplier : v.z;
            p.setDeltaMovement(x, y, z);
        }
    }

    public static class KillAuraModule extends Module {
        public double range = 4, attackSpeed = 12;
        public String rotations = "Silent", target = "Players";
        public boolean swing = true, throughWalls = false;
        public Entity currentTarget;
        private long last;
        KillAuraModule() { super("Kill Aura", "Combat", "Automated nearby targeting", GLFW.GLFW_KEY_R); }
        @Override public void tick() {
            Minecraft mc = Minecraft.getInstance(); LocalPlayer p = mc.player;
            if (p == null || mc.level == null || mc.gameMode == null || mc.screen != null) return;
            long now = System.currentTimeMillis();
            if (now - last < 1000.0 / Math.max(1, attackSpeed)) return;
            Entity best = null; double bestD = range * range;
            for (Entity e : mc.level.entitiesForRendering()) {
                if (e == p || !e.isAlive() || e.isSpectator()) continue;
                boolean allowed = switch (target) {
                    case "Players" -> e instanceof Player && e != p;
                    case "Mobs" -> e instanceof LivingEntity && !(e instanceof Player);
                    case "All" -> e instanceof LivingEntity && !(e instanceof Player && e.isSpectator());
                    default -> e instanceof Player;
                };
                if (!allowed) continue;
                double d = p.distanceToSqr(e);
                if (d < bestD && (throughWalls || p.hasLineOfSight(e))) { best = e; bestD = d; }
            }
            currentTarget = best;
            if (best != null) {
                if ("Snap".equals(rotations)) {
                    p.lookAt(net.minecraft.commands.arguments.EntityAnchorArgument.Anchor.EYES, best.getEyePosition());
                }
                mc.gameMode.attack(p, best);
                if (swing) p.swing(net.minecraft.world.InteractionHand.MAIN_HAND);
                last = now;
                if (Modules.NOTIFICATIONS.combat) OpusClient.notify("Kill Aura", "Target: " + best.getName().getString());
            }
        }
        @Override public void onDisable() { currentTarget = null; }
    }

    public static class FreeLookModule extends Module {
        public double sensitivity = 1;
        public String holdKey = "Alt";
        public boolean lockBody = true;
        public float cameraYaw, cameraPitch;
        FreeLookModule() { super("Free Look", "Visual", "Independent camera look", GLFW.GLFW_KEY_C); }
        @Override public void onEnable() {
            LocalPlayer p = Minecraft.getInstance().player;
            if (p != null) { cameraYaw = p.getYRot(); cameraPitch = p.getXRot(); }
        }
        public void updateLook(double dx, double dy) {
            cameraYaw += (float)(dx * sensitivity * .15);
            cameraPitch += (float)(dy * sensitivity * .15);
            cameraPitch = Math.max(-90, Math.min(90, cameraPitch));
        }
    }

    public static class ESPModule extends Module {
        public boolean players = true, mobs = true, items = true, tracers = false;
        public String colorMode = "Health";
        public double maxDistance = 128;
        ESPModule() { super("ESP", "Visual", "Entity boxes and tracers", GLFW.GLFW_KEY_X); }
    }

    public static class XRayModule extends Module {
        public boolean ores = true, chests = true, spawners = true;
        public double opacity = 20, scanRange = 32;
        XRayModule() { super("X-Ray", "Visual", "Find valuable blocks through terrain", GLFW.GLFW_KEY_Y); }
    }

    public static class BaseFinderModule extends Module {
        public double radius = 128, minCluster = 3;
        public boolean chests = true, torches = true, signs = true;
        BaseFinderModule() { super("Base Finder", "Utility", "Scan for common base indicators", GLFW.GLFW_KEY_B); }
    }

    public static class ProjectilesModule extends Module {
        public boolean trace = true, landing = true, predict = true;
        public String color = "Purple";
        ProjectilesModule() { super("Projectiles", "Combat", "Predict projectile trajectories", GLFW.GLFW_KEY_P); }
    }

    public static class FastBreakModule extends Module {
        public double speed = 5;
        public boolean insta = false, packet = true;
        FastBreakModule() { super("Fast Break", "Utility", "Accelerate block breaking", GLFW.GLFW_KEY_G); }
        @Override public void tick() {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player == null || mc.level == null || mc.gameMode == null || !mc.options.keyAttack.isDown()) return;
            if (!(mc.hitResult instanceof net.minecraft.world.phys.BlockHitResult hit)) return;
            if (mc.player.isSpectator()) return;
            if (insta) {
                mc.gameMode.breakBlock(hit.getBlockPos());
            } else if (packet) {
                int repeats = Math.max(1, Math.min(8, (int)Math.round(speed)));
                for (int i = 0; i < repeats; i++) mc.gameMode.updateBlockBreakingProgress(hit.getBlockPos(), hit.getDirection());
            }
        }
    }

    public static class BuildMapModule extends Module {
        public String schematic = "None";
        public double speed = 5;
        public boolean guide = true, auto = false;
        public int placedThisTick = 0;
        BuildMapModule() { super("Build Map", "Utility", "Guided blueprint and block placement", GLFW.GLFW_KEY_H); }
        @Override public void tick() {
            placedThisTick = 0;
            WorldFeatures.tickBuildMap(this);
        }
    }

    public static class MP3Module extends Module {
        public double volume = 80;
        public boolean shuffle = false, bass = false, showHud = true, playing = false;
        public String track = "No track";
        MP3Module() { super("MP3 Player", "QoL", "Play local MP3 files from config/opusclient/music", GLFW.GLFW_KEY_M); }
        @Override public void onEnable() {
            AudioPlayer.start();
            playing = AudioPlayer.playing();
            track = AudioPlayer.trackName();
        }
        @Override public void onDisable() {
            AudioPlayer.stop();
            playing = false;
        }
        @Override public void tick() {
            if (!AudioPlayer.playing() && playing) playing = false;
            if (playing) track = AudioPlayer.trackName();
        }
    }

    public static class NotificationsModule extends Module {
        public boolean combat = true, mentions = true, friend = true, sound = true;
        public double duration = 5;
        NotificationsModule() { super("Notifications", "QoL", "Gameplay event notifications", GLFW.GLFW_KEY_N); }
    }
}
