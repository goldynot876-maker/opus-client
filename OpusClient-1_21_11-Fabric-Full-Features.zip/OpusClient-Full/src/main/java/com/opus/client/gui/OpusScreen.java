package com.opus.client.gui;

import com.opus.client.module.Module;
import com.opus.client.module.Modules;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import java.util.*;

public class OpusScreen extends Screen {
    private String category = "All";
    private Module selected = null;
    private int scroll = 0;
    private long openTime = 0;
    private final String[] cats = {"All","Movement","Combat","Visual","Utility","QoL"};

    // Layout constants
    private static final int SIDEBAR_W = 300;
    private static final int TOP_BAR_H = 110;
    private static final int CARD_W = 160;
    private static final int CARD_H = 90;
    private static final int CARD_GAP = 8;
    private static final int GRID_X = 30;
    private static final int GRID_Y = TOP_BAR_H + 10;

    // Colors
    private static final int COL_BG       = 0xE5050010;
    private static final int COL_PANEL    = 0xF00A001A;
    private static final int COL_CARD     = 0xF0100220;
    private static final int COL_CARD_ON  = 0xF0200840;
    private static final int COL_ACCENT   = 0xFFA855F7;
    private static final int COL_ACCENT2  = 0xFFE879F9;
    private static final int COL_TEXT     = 0xFFEDD5FF;
    private static final int COL_MUTED    = 0xFF8B72A8;
    private static final int COL_DIM      = 0xFF4A2870;
    private static final int COL_SEP      = 0xFF2A1050;
    private static final int COL_ON_PILL  = 0xFF7C3AED;
    private static final int COL_OFF_PILL = 0xFF1E0940;
    private static final int COL_TOPBAR   = 0xF50D001F;

    public OpusScreen() { super(Component.literal("Opus Client")); }

    private boolean inCat(Module m) { return category.equals("All") || m.category.equals(category); }

    @Override
    public void init() {
        super.init();
        openTime = System.currentTimeMillis();
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float delta) {
        // Full background
        fillRect(g, 0, 0, width, height, COL_BG);

        // Top bar background
        fillRect(g, 0, 0, width, TOP_BAR_H, COL_TOPBAR);
        // Top bar bottom border
        fillRect(g, 0, TOP_BAR_H - 1, width, TOP_BAR_H, COL_SEP);
        // Accent line at very top
        drawGradientH(g, 0, 0, width, 2, COL_ACCENT, COL_ACCENT2);

        // Logo
        String logo = "✦ Opus Client";
        g.drawString(font, logo, 30, 18, COL_ACCENT, false);
        // Version tag
        g.drawString(font, "v1.1 • 1.21.11", 30, 34, COL_DIM, false);
        // Status
        String status = Modules.active() + " modules active • toms3gg anarchy";
        g.drawString(font, status, 30, 50, COL_MUTED, false);

        // Category pills
        int px = 30, py = 68;
        for (String c : cats) {
            int tw = font.width(c);
            int pw = tw + 20;
            boolean on = category.equals(c);
            int pillBg = on ? COL_ON_PILL : COL_OFF_PILL;
            int pillTx = on ? 0xFFFFFFFF : COL_MUTED;
            fillRect(g, px, py, px + pw, py + 22, pillBg);
            if (on) fillRect(g, px, py, px + pw, py + 1, COL_ACCENT);
            g.drawString(font, c, px + 10, py + 7, pillTx, false);
            px += pw + 6;
        }

        // Separator before grid
        fillRect(g, 0, TOP_BAR_H, width, TOP_BAR_H + 1, COL_SEP);

        // Module grid
        int gridW = selected != null ? width - SIDEBAR_W - GRID_X - 10 : width - GRID_X - 10;
        int cols = Math.max(1, gridW / (CARD_W + CARD_GAP));
        int i = 0;
        for (Module m : Modules.ALL) {
            if (!inCat(m)) continue;
            int col = i % cols, row = i / cols;
            int cx = GRID_X + col * (CARD_W + CARD_GAP);
            int cy = GRID_Y + row * (CARD_H + CARD_GAP) - scroll;
            if (cy + CARD_H < GRID_Y || cy > height - 20) { i++; continue; }
            drawCard(g, m, cx, cy, mx, my);
            i++;
        }

        // Side panel
        if (selected != null) drawPanel(g, selected);

        // Bottom bar
        fillRect(g, 0, height - 22, width, height, COL_TOPBAR);
        fillRect(g, 0, height - 23, width, height - 22, COL_SEP);
        g.drawString(font, "Right Shift: close  •  Click card: settings  •  Click toggle: enable/disable", 30, height - 15, COL_DIM, false);

        super.render(g, mx, my, delta);
    }

    private void drawCard(GuiGraphics g, Module m, int x, int y, int mx, int my) {
        boolean hover = mx >= x && mx <= x + CARD_W && my >= y && my <= y + CARD_H;
        boolean sel   = selected == m;

        int bg = m.enabled() ? COL_CARD_ON : COL_CARD;
        if (hover || sel) bg = blend(bg, 0x0FFFFFFF);
        fillRect(g, x, y, x + CARD_W, y + CARD_H, bg);

        // left accent bar
        if (m.enabled()) fillRect(g, x, y, x + 3, y + CARD_H, COL_ACCENT);
        else if (sel)    fillRect(g, x, y, x + 3, y + CARD_H, COL_SEP);

        // top shimmer if enabled
        if (m.enabled()) drawGradientH(g, x + 3, y, x + CARD_W, y + 1, COL_ACCENT, 0x00A855F7);

        // outline
        int outlineCol = sel ? COL_ACCENT : (hover ? COL_SEP : 0xFF120330);
        drawOutline(g, x, y, x + CARD_W, y + CARD_H, outlineCol);

        // Module name
        g.drawString(font, m.name, x + 12, y + 12, m.enabled() ? COL_TEXT : 0xFFCCBBE0, false);
        // Category
        g.drawString(font, m.category, x + 12, y + 27, COL_DIM, false);
        // Description (truncated)
        String desc = m.description.length() > 22 ? m.description.substring(0, 21) + "…" : m.description;
        g.drawString(font, desc, x + 12, y + 44, COL_MUTED, false);

        // ON/OFF pill
        int pillBg = m.enabled() ? COL_ON_PILL : COL_OFF_PILL;
        int pillX = x + 12, pillY = y + 62, pillW = 44, pillH = 18;
        fillRect(g, pillX, pillY, pillX + pillW, pillY + pillH, pillBg);
        if (m.enabled()) drawGradientH(g, pillX, pillY, pillX + pillW, pillY + 1, COL_ACCENT, COL_ACCENT2);
        g.drawString(font, m.enabled() ? "ON" : "OFF", pillX + (pillW - font.width(m.enabled()?"ON":"OFF")) / 2, pillY + 5, 0xFFFFFFFF, false);

        // key hint
        if (m.key > 0) {
            String kLabel = keyName(m.key);
            g.drawString(font, kLabel, x + CARD_W - font.width(kLabel) - 8, y + 65, COL_DIM, false);
        }
    }

    private void drawPanel(GuiGraphics g, Module m) {
        int x = width - SIDEBAR_W, y = 0, w = SIDEBAR_W, h = height;
        fillRect(g, x, y, x + w, y + h, COL_PANEL);
        fillRect(g, x, y, x + 1, y + h, COL_SEP);
        drawGradientH(g, x, y, x + w, y + 2, COL_ACCENT, COL_ACCENT2);

        // Header
        g.drawString(font, m.name, x + 20, y + 18, COL_TEXT, false);
        g.drawString(font, m.category + " module", x + 20, y + 34, COL_MUTED, false);
        // Status badge
        String badge = m.enabled() ? "ENABLED" : "DISABLED";
        int badgeCol = m.enabled() ? COL_ON_PILL : 0xFF1A0A30;
        int bw = font.width(badge) + 16;
        fillRect(g, x + w - bw - 16, y + 20, x + w - 16, y + 36, badgeCol);
        if (m.enabled()) drawGradientH(g, x + w - bw - 16, y + 20, x + w - 16, y + 21, COL_ACCENT, COL_ACCENT2);
        g.drawString(font, badge, x + w - bw - 8, y + 25, m.enabled() ? 0xFFFFFFFF : COL_MUTED, false);

        // Divider
        fillRect(g, x + 16, y + 50, x + w - 16, y + 51, COL_SEP);

        // Description
        g.drawString(font, "Description", x + 20, y + 60, COL_DIM, false);
        g.drawString(font, m.description, x + 20, y + 75, COL_MUTED, false);

        // Divider
        fillRect(g, x + 16, y + 95, x + w - 16, y + 96, COL_SEP);

        // Settings label
        g.drawString(font, "Settings", x + 20, y + 105, COL_DIM, false);

        // Settings rows
        int yy = y + 124;
        String[] lines = settings(m);
        for (String s : lines) {
            // split on two spaces to get key / value
            String[] parts = s.split("  ", 2);
            if (parts.length == 2) {
                g.drawString(font, parts[0], x + 20, yy, COL_MUTED, false);
                g.drawString(font, parts[1], x + w - font.width(parts[1]) - 20, yy, COL_TEXT, false);
            } else {
                g.drawString(font, s, x + 20, yy, COL_TEXT, false);
            }
            // row separator
            fillRect(g, x + 16, yy + 14, x + w - 16, yy + 15, 0xFF12022A);
            yy += 24;
        }

        // Close hint
        fillRect(g, x + 16, h - 36, x + w - 16, h - 35, COL_SEP);
        g.drawString(font, "Click elsewhere to close", x + 20, h - 26, COL_DIM, false);
    }

    // ── helpers ──────────────────────────────────────────────────────────────

    private void fillRect(GuiGraphics g, int x1, int y1, int x2, int y2, int color) {
        g.fill(x1, y1, x2, y2, color);
    }

    private void drawOutline(GuiGraphics g, int x1, int y1, int x2, int y2, int color) {
        g.fill(x1, y1, x2, y1 + 1, color);
        g.fill(x1, y2 - 1, x2, y2, color);
        g.fill(x1, y1, x1 + 1, y2, color);
        g.fill(x2 - 1, y1, x2, y2, color);
    }

    private void drawGradientH(GuiGraphics g, int x1, int y1, int x2, int y2, int left, int right) {
        net.minecraft.client.renderer.RenderType rt = net.minecraft.client.renderer.RenderType.gui();
        g.fillGradient(x1, y1, x2, y2, left, right);
    }

    private int blend(int base, int overlay) { return base; } // placeholder, colours work as-is

    private String keyName(int key) {
        return switch(key) {
            case org.lwjgl.glfw.GLFW.GLFW_KEY_F -> "[F]";
            case org.lwjgl.glfw.GLFW.GLFW_KEY_V -> "[V]";
            case org.lwjgl.glfw.GLFW.GLFW_KEY_R -> "[R]";
            case org.lwjgl.glfw.GLFW.GLFW_KEY_C -> "[C]";
            case org.lwjgl.glfw.GLFW.GLFW_KEY_X -> "[X]";
            case org.lwjgl.glfw.GLFW.GLFW_KEY_Y -> "[Y]";
            case org.lwjgl.glfw.GLFW.GLFW_KEY_B -> "[B]";
            case org.lwjgl.glfw.GLFW.GLFW_KEY_P -> "[P]";
            case org.lwjgl.glfw.GLFW.GLFW_KEY_G -> "[G]";
            case org.lwjgl.glfw.GLFW.GLFW_KEY_H -> "[H]";
            case org.lwjgl.glfw.GLFW.GLFW_KEY_M -> "[M]";
            case org.lwjgl.glfw.GLFW.GLFW_KEY_N -> "[N]";
            default -> "";
        };
    }

    private String[] settings(Module m) {
        if (m == Modules.FLY)           { var a=Modules.FLY;           return new String[]{"Speed  "+a.speed,"Max Height  "+a.maxHeight,"Mode  "+a.mode,"Anti-Kick  "+a.antiKick}; }
        if (m == Modules.VELOCITY)      { var a=Modules.VELOCITY;      return new String[]{"Delay  "+a.delay+" ms","Multiplier  "+a.multiplier,"Horizontal  "+a.horizontal,"Vertical  "+a.vertical,"Packets  "+a.packets}; }
        if (m == Modules.KILLAURA)      { var a=Modules.KILLAURA;      return new String[]{"Range  "+a.range,"Attack Speed  "+a.attackSpeed,"Rotations  "+a.rotations,"Target  "+a.target,"Swing  "+a.swing,"Through Walls  "+a.throughWalls}; }
        if (m == Modules.FREELOOK)      { var a=Modules.FREELOOK;      return new String[]{"Sensitivity  "+a.sensitivity,"Hold Key  "+a.holdKey,"Lock Body  "+a.lockBody}; }
        if (m == Modules.ESP)           { var a=Modules.ESP;           return new String[]{"Players  "+a.players,"Mobs  "+a.mobs,"Items  "+a.items,"Color Mode  "+a.colorMode,"Tracers  "+a.tracers,"Max Distance  "+a.maxDistance}; }
        if (m == Modules.XRAY)          { var a=Modules.XRAY;          return new String[]{"Show Ores  "+a.ores,"Show Chests  "+a.chests,"Show Spawners  "+a.spawners,"World Opacity  "+a.opacity,"Scan Range  "+a.scanRange}; }
        if (m == Modules.BASE)          { var a=Modules.BASE;          return new String[]{"Search Radius  "+a.radius,"Chest Clusters  "+a.chests,"Torch Patterns  "+a.torches,"Signs  "+a.signs,"Min Cluster  "+a.minCluster}; }
        if (m == Modules.PROJECTILES)   { var a=Modules.PROJECTILES;   return new String[]{"Show Trace  "+a.trace,"Landing Point  "+a.landing,"Trace Color  "+a.color,"Entity Predict  "+a.predict}; }
        if (m == Modules.FASTBREAK)     { var a=Modules.FASTBREAK;     return new String[]{"Break Speed  "+a.speed,"Insta Break  "+a.insta,"Packet Mine  "+a.packet}; }
        if (m == Modules.BUILDMAP)      { var a=Modules.BUILDMAP;      return new String[]{"Schematic  "+a.schematic,"Place Speed  "+a.speed,"Show Guide  "+a.guide,"Auto Place  "+a.auto}; }
        if (m == Modules.MP3)           { var a=Modules.MP3;           return new String[]{"Volume  "+a.volume,"Shuffle  "+a.shuffle,"Bass Boost  "+a.bass,"Show HUD  "+a.showHud,"Track  "+a.track}; }
        var a = Modules.NOTIFICATIONS;  return new String[]{"Combat Alerts  "+a.combat,"Chat Mentions  "+a.mentions,"Friend Join  "+a.friend,"Sound  "+a.sound,"Duration  "+a.duration+"s"};
    }

    // ── input ────────────────────────────────────────────────────────────────

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        // Category pills
        int px = 30, py = 68;
        for (String c : cats) {
            int pw = font.width(c) + 20;
            if (mx >= px && mx <= px + pw && my >= py && my <= py + 22) {
                category = c; selected = null; return true;
            }
            px += pw + 6;
        }

        // Settings panel rows: click a value to cycle/toggle it.
        if (selected != null && mx >= width - SIDEBAR_W) {
            int yy = 124;
            int row = 0;
            for (String ignored : settings(selected)) {
                if (my >= yy - 5 && my <= yy + 15) {
                    cycleSetting(selected, row);
                    return true;
                }
                yy += 24; row++;
            }
        }

        // Side panel close on click-outside
        if (selected != null && mx < width - SIDEBAR_W) { selected = null; return true; }

        // Cards
        int gridW = selected != null ? width - SIDEBAR_W - GRID_X - 10 : width - GRID_X - 10;
        int cols = Math.max(1, gridW / (CARD_W + CARD_GAP));
        int i = 0;
        for (Module m : Modules.ALL) {
            if (!inCat(m)) continue;
            int col = i % cols, row = i / cols;
            int cx = GRID_X + col * (CARD_W + CARD_GAP);
            int cy = GRID_Y + row * (CARD_H + CARD_GAP) - scroll;
            if (mx >= cx && mx <= cx + CARD_W && my >= cy && my <= cy + CARD_H) {
                // Click pill = toggle, click elsewhere = open panel
                int pillX = cx + 12, pillY = cy + 62, pillW = 44, pillH = 18;
                if (mx >= pillX && mx <= pillX + pillW && my >= pillY && my <= pillY + pillH) {
                    m.toggle();
                    com.opus.client.OpusClient.notify(m.name, m.enabled() ? "Enabled" : "Disabled");
                } else {
                    selected = (selected == m) ? null : m;
                }
                return true;
            }
            i++;
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double dx, double dy) {
        scroll = Math.max(0, scroll - (int)(dy * 25));
        return true;
    }

    @Override
    public boolean keyPressed(int key, int scancode, int mods) {
        if (key == 256) { onClose(); return true; }
        return super.keyPressed(key, scancode, mods);
    }


    private void cycleSetting(Module m, int row) {
        if (m == Modules.FLY) { var a=Modules.FLY; switch(row){case 0->a.speed=a.speed>=4?0.5:a.speed+0.5;case 1->a.maxHeight=a.maxHeight>=320?128:a.maxHeight+64;case 2->a.mode=switch(a.mode){case "Boost"->"Glide";case "Glide"->"Vanilla";default->"Boost";};case 3->a.antiKick=!a.antiKick;} }
        else if (m == Modules.VELOCITY) { var a=Modules.VELOCITY; switch(row){case 0->a.delay=a.delay>=300?0:a.delay+50;case 1->a.multiplier=a.multiplier>=1?0:a.multiplier+0.1;case 2->a.horizontal=!a.horizontal;case 3->a.vertical=!a.vertical;case 4->a.packets=a.packets>=4?1:a.packets+1;} }
        else if (m == Modules.KILLAURA) { var a=Modules.KILLAURA; switch(row){case 0->a.range=a.range>=6?2:a.range+0.5;case 1->a.attackSpeed=a.attackSpeed>=20?4:a.attackSpeed+2;case 2->a.rotations="Silent".equals(a.rotations)?"Snap":"Silent";case 3->a.target=switch(a.target){case "Players"->"Mobs";case "Mobs"->"All";default->"Players";};case 4->a.swing=!a.swing;case 5->a.throughWalls=!a.throughWalls;} }
        else if (m == Modules.FREELOOK) { var a=Modules.FREELOOK; switch(row){case 0->a.sensitivity=a.sensitivity>=2?0.5:a.sensitivity+0.25;case 1->a.holdKey="Alt".equals(a.holdKey)?"C":"Alt";case 2->a.lockBody=!a.lockBody;} }
        else if (m == Modules.ESP) { var a=Modules.ESP; switch(row){case 0->a.players=!a.players;case 1->a.mobs=!a.mobs;case 2->a.items=!a.items;case 3->a.colorMode="Health".equals(a.colorMode)?"Purple":"Health";case 4->a.tracers=!a.tracers;case 5->a.maxDistance=a.maxDistance>=256?32:a.maxDistance+32;} }
        else if (m == Modules.XRAY) { var a=Modules.XRAY; switch(row){case 0->a.ores=!a.ores;case 1->a.chests=!a.chests;case 2->a.spawners=!a.spawners;case 3->a.opacity=a.opacity>=80?10:a.opacity+10;case 4->a.scanRange=a.scanRange>=48?16:a.scanRange+8;} }
        else if (m == Modules.BASE) { var a=Modules.BASE; switch(row){case 0->a.radius=a.radius>=1000?128:a.radius+128;case 1->a.chests=!a.chests;case 2->a.torches=!a.torches;case 3->a.signs=!a.signs;case 4->a.minCluster=a.minCluster>=8?1:a.minCluster+1;} }
        else if (m == Modules.PROJECTILES) { var a=Modules.PROJECTILES; switch(row){case 0->a.trace=!a.trace;case 1->a.landing=!a.landing;case 2->a.color="Purple".equals(a.color)?"White":"Purple";case 3->a.predict=!a.predict;} }
        else if (m == Modules.FASTBREAK) { var a=Modules.FASTBREAK; switch(row){case 0->a.speed=a.speed>=8?1:a.speed+1;case 1->a.insta=!a.insta;case 2->a.packet=!a.packet;} }
        else if (m == Modules.BUILDMAP) { var a=Modules.BUILDMAP; switch(row){case 0->a.schematic="None".equals(a.schematic)?"Guide":"None";case 1->a.speed=a.speed>=10?1:a.speed+1;case 2->a.guide=!a.guide;case 3->a.auto=!a.auto;} }
        else if (m == Modules.MP3) { var a=Modules.MP3; switch(row){case 0->a.volume=a.volume>=100?0:a.volume+10;case 1->a.shuffle=!a.shuffle;case 2->a.bass=!a.bass;case 3->a.showHud=!a.showHud;case 4->a.playing=!a.playing;} }
        else if (m == Modules.NOTIFICATIONS) { var a=Modules.NOTIFICATIONS; switch(row){case 0->a.combat=!a.combat;case 1->a.mentions=!a.mentions;case 2->a.friend=!a.friend;case 3->a.sound=!a.sound;case 4->a.duration=a.duration>=10?1:a.duration+1;} }
    }

    @Override public boolean isPauseScreen() { return false; }
}
