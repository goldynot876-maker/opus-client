package com.opus.client;

import com.opus.client.module.Modules;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;
import net.minecraft.client.gui.GuiGraphics;

public final class OpusHud {
 public static void register(){ HudElementRegistry.addLast(Identifier.fromNamespaceAndPath("opusclient","hud"),(g,dt)->render(g)); }
 private static void render(GuiGraphics g){
  Minecraft mc=Minecraft.getInstance(); int w=mc.getWindow().getGuiScaledWidth();
  int islandW=260,x=(w-islandW)/2;g.fill(x,8,x+islandW,38,0xFF050007);g.fill(x,8,x+4,38,0xFFA855F7);
  String server="Singleplayer";int ping=0;if(mc.getCurrentServer()!=null){server=mc.getCurrentServer().name;}if(mc.getConnection()!=null&&mc.player!=null&&mc.getConnection().getPlayerInfo(mc.player.getUUID())!=null)ping=mc.getConnection().getPlayerInfo(mc.player.getUUID()).getLatency();
  g.drawString(mc.font,"OPUS CLIENT",x+15,13,0xFFE9D5FF,false);g.drawString(mc.font,Modules.active()+" active • "+ping+" ms • "+server,x+15,25,0xFF9D8EAF,false);
  int ty=48; synchronized(OpusClient.toasts()){for(var t:OpusClient.toasts()){long age=System.currentTimeMillis()-t.time();float a=Math.max(0,Math.min(1,(5000-age)/350f));if(a<=0)continue;int tw=300,tx=w-tw-20;g.fill(tx,ty,tx+tw,ty+60,((int)(a*255)<<24)|0x100519);g.fill(tx,ty,tx+3,ty+60,((int)(a*255)<<24)|0xA855F7);g.drawString(mc.font,t.title(),tx+14,ty+14,((int)(a*255)<<24)|0xFFF5EFFF,false);g.drawString(mc.font,t.subtitle(),tx+14,ty+32,((int)(a*255)<<24)|0xFF9F91AD,false);ty+=68;}}
  if(Modules.MP3.showHud&&Modules.MP3.playing){g.fill(w-260,ty,w-20,ty+34,0xDD160824);g.drawString(mc.font,"♫ "+Modules.MP3.track,w-248,ty+11,0xFFC084FC,false);}
 }
}
