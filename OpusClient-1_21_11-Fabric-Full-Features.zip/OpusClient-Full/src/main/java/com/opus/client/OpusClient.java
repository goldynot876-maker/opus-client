package com.opus.client;

import com.opus.client.gui.OpusScreen;
import com.opus.client.config.OpusConfig;
import com.opus.client.module.Module;
import com.opus.client.module.Modules;
import com.opus.client.render.WorldFeatures;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;
import java.util.*;

public class OpusClient implements ClientModInitializer {
    public static final String MODID="opusclient";
    public static KeyMapping GUI_KEY;
    private static final List<Toast> TOASTS=new ArrayList<>();
    private static final Map<KeyMapping, Module> KEY_MODULES=new HashMap<>();
    @Override public void onInitializeClient(){
        GUI_KEY=KeyBindingHelper.registerKeyBinding(new KeyMapping("key.opus.open_gui",GLFW.GLFW_KEY_RIGHT_SHIFT,KeyMapping.Category.MISC));
        for(Module m: Modules.ALL) { KeyMapping k=KeyBindingHelper.registerKeyBinding(new KeyMapping("key.opus."+m.name.toLowerCase().replace(" ","_"),m.key,KeyMapping.Category.MISC)); KEY_MODULES.put(k,m); }
        OpusHud.register();
        WorldFeatures.register();
        OpusConfig.load();
        ClientTickEvents.END_CLIENT_TICK.register(mc->{while(GUI_KEY.consumeClick())mc.setScreen(new OpusScreen()); for(var e:KEY_MODULES.entrySet()) while(e.getKey().consumeClick()){e.getValue().toggle(); OpusConfig.save(); notify(e.getValue().name,e.getValue().enabled()?"Enabled":"Disabled");} Modules.tick(); synchronized(TOASTS){TOASTS.removeIf(t->System.currentTimeMillis()-t.time>t.duration);}});
    }
    public static void notify(String title,String subtitle){ synchronized(TOASTS){TOASTS.add(new Toast(title,subtitle,System.currentTimeMillis(),5000)); } }
    public static List<Toast> toasts(){return TOASTS;}
    public record Toast(String title,String subtitle,long time,long duration){}
}
