package com.opus.client.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.opus.client.module.Modules;
import net.minecraft.client.Minecraft;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public final class OpusConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static Path path() { return Minecraft.getInstance().gameDirectory.toPath().resolve("config/opusclient.json"); }
    private OpusConfig() {}
    public static void save() {
        JsonObject root = new JsonObject();
        for (var m : Modules.ALL) root.addProperty(m.name, m.enabled());
        root.addProperty("mp3Volume", Modules.MP3.volume);
        root.addProperty("espDistance", Modules.ESP.maxDistance);
        root.addProperty("xrayRange", Modules.XRAY.scanRange);
        root.addProperty("baseRadius", Modules.BASE.radius);
        try { Files.createDirectories(path().getParent()); Files.writeString(path(), GSON.toJson(root)); } catch (IOException ignored) {}
    }
    public static void load() {
        if (!Files.exists(path())) return;
        try {
            JsonObject root = GSON.fromJson(Files.readString(path()), JsonObject.class);
            for (var m : Modules.ALL) if (root.has(m.name)) m.setEnabled(root.get(m.name).getAsBoolean());
            if (root.has("mp3Volume")) Modules.MP3.volume = root.get("mp3Volume").getAsDouble();
            if (root.has("espDistance")) Modules.ESP.maxDistance = root.get("espDistance").getAsDouble();
            if (root.has("xrayRange")) Modules.XRAY.scanRange = root.get("xrayRange").getAsDouble();
            if (root.has("baseRadius")) Modules.BASE.radius = root.get("baseRadius").getAsDouble();
        } catch (Exception ignored) {}
    }
}
