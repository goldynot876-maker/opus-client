package com.opus.client.mixin;

import com.opus.client.module.Modules;
import net.minecraft.client.render.Camera;
import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Camera.class)
public abstract class CameraMixin {
    @Shadow protected abstract void setRotation(float yaw, float pitch);

    @Inject(method = "update", at = @At("TAIL"))
    private void opus$applyFreeLook(net.minecraft.world.level.Level level, net.minecraft.world.entity.Entity entity, boolean thirdPerson, boolean inverseView, float tickProgress, CallbackInfo ci) {
        if (entity == Minecraft.getInstance().player && Modules.FREELOOK.enabled()) {
            setRotation(Modules.FREELOOK.cameraYaw, Modules.FREELOOK.cameraPitch);
        }
    }
}
