package com.opus.client.render;

import com.mojang.blaze3d.vertex.PoseStack;
import com.opus.client.OpusClient;
import com.opus.client.module.Modules;
import com.opus.client.module.Modules.BuildMapModule;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.VertexConsumer;
import net.minecraft.client.renderer.VertexRendering;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;

import java.util.*;

/** Shared world scanning/rendering for ESP, X-Ray, Base Finder, Projectiles and Build Map. */
public final class WorldFeatures {
    private static final Set<BlockPos> XRAY_BLOCKS = new LinkedHashSet<>();
    private static final Set<BlockPos> BASE_BLOCKS = new LinkedHashSet<>();
    private static int scanTimer;

    private WorldFeatures() {}

    public static void register() {
        WorldRenderEvents.AFTER_ENTITIES.register(WorldFeatures::render);
    }

    public static void tick() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;
        if (++scanTimer % 10 != 0) return;
        if (Modules.XRAY.enabled()) scanXray(mc);
        if (Modules.BASE.enabled()) scanBase(mc);
    }

    private static void scanXray(Minecraft mc) {
        XRAY_BLOCKS.clear();
        int r = (int)Math.min(48, Math.max(4, Modules.XRAY.scanRange));
        BlockPos c = mc.player.blockPosition();
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();
        for (int x=-r;x<=r;x++) for (int y=-r;y<=r;y++) for (int z=-r;z<=r;z++) {
            if (x*x+y*y+z*z > r*r) continue;
            p.set(c.getX()+x,c.getY()+y,c.getZ()+z);
            BlockState s=mc.level.getBlockState(p);
            boolean hit = (Modules.XRAY.ores && isOre(s)) ||
                    (Modules.XRAY.chests && (s.is(Blocks.CHEST)||s.is(Blocks.TRAPPED_CHEST))) ||
                    (Modules.XRAY.spawners && s.is(Blocks.SPAWNER));
            if (hit) XRAY_BLOCKS.add(p.immutable());
        }
    }

    private static void scanBase(Minecraft mc) {
        BASE_BLOCKS.clear();
        int r = (int)Math.min(96, Math.max(8, Modules.BASE.radius));
        int vertical = Math.min(32, r);
        BlockPos c=mc.player.blockPosition();
        BlockPos.MutableBlockPos p=new BlockPos.MutableBlockPos();
        for(int x=-r;x<=r;x+=2) for(int y=-vertical;y<=vertical;y+=2) for(int z=-r;z<=r;z+=2){
            if(x*x+z*z>r*r) continue;
            p.set(c.getX()+x,c.getY()+y,c.getZ()+z); BlockState s=mc.level.getBlockState(p);
            if((Modules.BASE.torches && isTorch(s)) || (Modules.BASE.signs && isSign(s)) ||
                    (Modules.BASE.chests && (s.is(Blocks.CHEST)||s.is(Blocks.TRAPPED_CHEST)))) BASE_BLOCKS.add(p.immutable());
        }
    }

    private static boolean isOre(BlockState s) {
        return s.is(Blocks.COAL_ORE)||s.is(Blocks.IRON_ORE)||s.is(Blocks.COPPER_ORE)||s.is(Blocks.GOLD_ORE)||
                s.is(Blocks.REDSTONE_ORE)||s.is(Blocks.EMERALD_ORE)||s.is(Blocks.LAPIS_ORE)||s.is(Blocks.DIAMOND_ORE)||
                s.is(Blocks.DEEPSLATE_COAL_ORE)||s.is(Blocks.DEEPSLATE_IRON_ORE)||s.is(Blocks.DEEPSLATE_COPPER_ORE)||
                s.is(Blocks.DEEPSLATE_GOLD_ORE)||s.is(Blocks.DEEPSLATE_REDSTONE_ORE)||s.is(Blocks.DEEPSLATE_EMERALD_ORE)||
                s.is(Blocks.DEEPSLATE_LAPIS_ORE)||s.is(Blocks.DEEPSLATE_DIAMOND_ORE)||s.is(Blocks.NETHER_GOLD_ORE)||
                s.is(Blocks.NETHER_QUARTZ_ORE);
    }
    private static boolean isTorch(BlockState s){return s.is(Blocks.TORCH)||s.is(Blocks.WALL_TORCH)||s.is(Blocks.SOUL_TORCH)||s.is(Blocks.SOUL_WALL_TORCH);}
    private static boolean isSign(BlockState s){return s.is(Blocks.OAK_SIGN)||s.is(Blocks.SPRUCE_SIGN)||s.is(Blocks.BIRCH_SIGN)||s.is(Blocks.JUNGLE_SIGN)||s.is(Blocks.ACACIA_SIGN)||s.is(Blocks.DARK_OAK_SIGN)||s.is(Blocks.MANGROVE_SIGN)||s.is(Blocks.CHERRY_SIGN)||s.is(Blocks.BAMBOO_SIGN)||s.is(Blocks.CRIMSON_SIGN)||s.is(Blocks.WARPED_SIGN);}

    private static void render(WorldRenderContext ctx) {
        Minecraft mc=Minecraft.getInstance();
        if(mc.level==null||mc.player==null||ctx.matrices()==null||ctx.consumers()==null) return;
        PoseStack matrices=ctx.matrices(); MultiBufferSource buffers=ctx.consumers();
        Vec3 cam=ctx.camera().getCameraPos();
        matrices.pushPose();
        matrices.translate(-cam.x,-cam.y,-cam.z);
        VertexConsumer lines=buffers.getBuffer(RenderType.lines());
        if(Modules.ESP.enabled()) renderEsp(ctx,matrices,lines,mc);
        if(Modules.XRAY.enabled()) for(BlockPos p:XRAY_BLOCKS) drawBox(matrices,lines,new AABB(p),0.65f,0.2f,1f,1f);
        if(Modules.BASE.enabled()) for(BlockPos p:BASE_BLOCKS) drawBox(matrices,lines,new AABB(p),1f,0.65f,0.15f,0.9f);
        if(Modules.PROJECTILES.enabled()) renderProjectiles(matrices,lines,mc);
        if(Modules.KILLAURA.enabled() && Modules.KILLAURA.currentTarget!=null) drawBox(matrices,lines,Modules.KILLAURA.currentTarget.getBoundingBox(),1f,.1f,.1f,1f);
        if(Modules.BUILDMAP.enabled() && Modules.BUILDMAP.guide) renderBuildGuide(matrices,lines,mc);
        matrices.popPose();
    }

    private static void renderEsp(WorldRenderContext ctx,PoseStack m,VertexConsumer v,Minecraft mc){
        Vec3 cam=ctx.camera().getCameraPos();
        for(Entity e:mc.level.entitiesForRendering()){
            if(e==mc.player) continue;
            if(e.distanceToSqr(mc.player)>Modules.ESP.maxDistance*Modules.ESP.maxDistance) continue;
            boolean ok=(Modules.ESP.players&&e instanceof Player)||(Modules.ESP.mobs&&e instanceof net.minecraft.world.entity.LivingEntity&&!(e instanceof Player))||(Modules.ESP.items&&e instanceof ItemEntity);
            if(!ok) continue;
            int color=0xFFFFFFFF;
            if("Health".equals(Modules.ESP.colorMode)&&e instanceof net.minecraft.world.entity.LivingEntity l){float hp=l.getHealth()/Math.max(1,l.getMaxHealth());color=healthColor(hp);}
            float a=0.95f;
            drawBox(m,v,e.getBoundingBox(),((color>>16)&255)/255f,((color>>8)&255)/255f,(color&255)/255f,a);
            if(Modules.ESP.tracers){Vec3 from=mc.player.getEyePosition();Vec3 to=e.getBoundingBox().getCenter();drawLine(m,v,from.x,from.y,from.z,to.x,to.y,to.z,1f,.35f,.8f,.8f);}
        }
    }

    private static int healthColor(float h){int r=(int)(255*(1-h)),g=(int)(255*h);return (r<<16)|(g<<8);}

    private static void renderProjectiles(PoseStack m,VertexConsumer v,Minecraft mc){
        for(Entity e:mc.level.entitiesForRendering()){
            if(!(e instanceof net.minecraft.world.entity.projectile.Projectile)) continue;
            Vec3 p=e.position(); Vec3 vel=e.getDeltaMovement();
            if(vel.lengthSqr()<1e-5) continue;
            double x=p.x,y=p.y,z=p.z; double vx=vel.x,vy=vel.y,vz=vel.z;
            int steps=Modules.PROJECTILES.predict?24:8;
            for(int i=0;i<steps;i++){
                double nx=x+vx,ny=y+vy,nz=z+vz;
                if(Modules.PROJECTILES.trace) drawLine(m,v,x,y,z,nx,ny,nz,.75f,.3f,1f,.9f);
                x=nx;y=ny;z=nz;vy-=.03;vx*=.99;vz*=.99;
                if(!mc.level.getBlockState(BlockPos.containing(x,y,z)).isAir()) {if(Modules.PROJECTILES.landing) drawBox(m,v,new AABB(BlockPos.containing(x,y,z)),.75f,.3f,1f,1f);break;}
            }
        }
    }

    private static void renderBuildGuide(PoseStack m,VertexConsumer v,Minecraft mc){
        if("None".equals(Modules.BUILDMAP.schematic)) return;
        BlockPos p=mc.player.blockPosition().relative(mc.player.getDirection());
        drawBox(m,v,new AABB(p),.75f,.3f,1f,.7f);
    }

    public static void tickBuildMap(BuildMapModule module){
        // The project has no schematic dependency. A working guide mode is provided; auto mode
        // only places the selected block when the player is holding it, preserving survival rules.
        if(!module.auto) return;
        Minecraft mc=Minecraft.getInstance();
        if(mc.player==null||mc.gameMode==null||mc.hitResult==null) return;
        if(!(mc.hitResult instanceof net.minecraft.world.phys.BlockHitResult hit)) return;
        if(mc.options.keyUse.isDown()){
            mc.gameMode.useItemOn(mc.player,net.minecraft.world.InteractionHand.MAIN_HAND,hit);
            module.placedThisTick++;
        }
    }

    private static void drawBox(PoseStack m,VertexConsumer v,AABB b,float r,float g,float bl,float a){
        double x1=b.minX,y1=b.minY,z1=b.minZ,x2=b.maxX,y2=b.maxY,z2=b.maxZ;
        drawLine(m,v,x1,y1,z1,x2,y1,z1,r,g,bl,a);drawLine(m,v,x2,y1,z1,x2,y1,z2,r,g,bl,a);drawLine(m,v,x2,y1,z2,x1,y1,z2,r,g,bl,a);drawLine(m,v,x1,y1,z2,x1,y1,z1,r,g,bl,a);
        drawLine(m,v,x1,y2,z1,x2,y2,z1,r,g,bl,a);drawLine(m,v,x2,y2,z1,x2,y2,z2,r,g,bl,a);drawLine(m,v,x2,y2,z2,x1,y2,z2,r,g,bl,a);drawLine(m,v,x1,y2,z2,x1,y2,z1,r,g,bl,a);
        drawLine(m,v,x1,y1,z1,x1,y2,z1,r,g,bl,a);drawLine(m,v,x2,y1,z1,x2,y2,z1,r,g,bl,a);drawLine(m,v,x2,y1,z2,x2,y2,z2,r,g,bl,a);drawLine(m,v,x1,y1,z2,x1,y2,z2,r,g,bl,a);
    }

    private static void drawLine(PoseStack m,VertexConsumer v,double x1,double y1,double z1,double x2,double y2,double z2,float r,float g,float b,float a){
        Matrix4f mat=m.last().pose();
        v.vertex(mat,(float)x1,(float)y1,(float)z1).color(r,g,b,a).normal(m.last(),0,1,0);
        v.vertex(mat,(float)x2,(float)y2,(float)z2).color(r,g,b,a).normal(m.last(),0,1,0);
    }
}
