package com.opus.client.audio;

import com.opus.client.module.Modules;
import net.minecraft.client.Minecraft;

import javax.sound.sampled.*;
import java.io.IOException;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;

/** Local MP3 playback. MP3 decoding is supplied by the mp3spi dependency in build.gradle. */
public final class AudioPlayer {
    private static final AtomicBoolean PLAYING = new AtomicBoolean(false);
    private static final Object LOCK = new Object();
    private static volatile Thread worker;
    private static volatile SourceDataLine line;
    private static volatile String track = "No track";

    private AudioPlayer() {}

    public static void start() {
        synchronized (LOCK) {
            if (PLAYING.get()) return;
            List<Path> files = files();
            if (files.isEmpty()) { track = "No MP3 files"; return; }
            PLAYING.set(true);
            worker = new Thread(() -> run(files), "Opus-MP3");
            worker.setDaemon(true);
            worker.start();
        }
    }

    public static void stop() {
        PLAYING.set(false);
        SourceDataLine l = line;
        if (l != null) { try { l.stop(); } catch (Exception ignored) {} try { l.close(); } catch (Exception ignored) {} }
        Thread t = worker;
        if (t != null) t.interrupt();
    }

    public static boolean playing() { return PLAYING.get(); }
    public static String trackName() { return track; }

    private static List<Path> files() {
        Path dir = Minecraft.getInstance().gameDirectory.toPath().resolve("config/opusclient/music");
        try { Files.createDirectories(dir); } catch (IOException ignored) {}
        try (var stream = Files.list(dir)) {
            return stream.filter(p -> p.getFileName().toString().toLowerCase(Locale.ROOT).endsWith(".mp3")).sorted().toList();
        } catch (IOException e) { return List.of(); }
    }

    private static void run(List<Path> files) {
        int index = 0;
        try {
            while (PLAYING.get()) {
                if (index >= files.size()) index = 0;
                Path file = files.get(index++);
                track = file.getFileName().toString();
                play(file);
                if (Modules.MP3.shuffle) Collections.shuffle(files);
            }
        } finally {
            PLAYING.set(false);
            SourceDataLine l = line;
            if (l != null) { try { l.stop(); } catch (Exception ignored) {} try { l.close(); } catch (Exception ignored) {} }
        }
    }

    private static void play(Path file) {
        try (AudioInputStream raw = AudioSystem.getAudioInputStream(file.toFile())) {
            AudioFormat base = raw.getFormat();
            int channels = Math.max(1, Math.min(2, base.getChannels()));
            AudioFormat pcm = new AudioFormat(AudioFormat.Encoding.PCM_SIGNED, 44100, 16,
                    channels, channels * 2, 44100, false);
            try (AudioInputStream in = AudioSystem.getAudioInputStream(pcm, raw)) {
                DataLine.Info info = new DataLine.Info(SourceDataLine.class, pcm);
                SourceDataLine out = (SourceDataLine) AudioSystem.getLine(info);
                line = out;
                out.open(pcm);
                applyVolume(out);
                out.start();
                byte[] buf = new byte[8192];
                int n;
                while (PLAYING.get() && !Thread.currentThread().isInterrupted() && (n = in.read(buf)) >= 0) {
                    if (n > 0) out.write(buf, 0, n);
                    applyVolume(out);
                }
                out.stop();
                out.close();
                line = null;
            }
        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException ignored) {
            PLAYING.set(false);
        }
    }

    private static void applyVolume(SourceDataLine out) {
        try {
            if (out.isControlSupported(FloatControl.Type.MASTER_GAIN)) {
                FloatControl c = (FloatControl) out.getControl(FloatControl.Type.MASTER_GAIN);
                float pct = (float)Math.max(0.0, Math.min(100.0, Modules.MP3.volume));
                float db = pct <= 0 ? c.getMinimum() : (float)(20.0 * Math.log10(pct / 100.0));
                if (Modules.MP3.bass) db += 3.0f;
                c.setValue(Math.max(c.getMinimum(), Math.min(c.getMaximum(), db)));
            }
        } catch (Exception ignored) {}
    }
}
