Build Map uses a simple guide format in this source version. A future format parser can be added without changing the GUI.
The included guide mode is intentionally server-safe: it does not edit the world directly.
