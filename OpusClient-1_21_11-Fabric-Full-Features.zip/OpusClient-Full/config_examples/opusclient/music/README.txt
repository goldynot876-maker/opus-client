Put .mp3 files in Minecraft/config/opusclient/music/
Enable MP3 Player in Opus GUI. The player will loop the local files and supports volume, shuffle and a small bass boost.
